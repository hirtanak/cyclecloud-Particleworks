import os
import re
import sys
from setuptools import setup, find_packages
from setuptools.command.test import test as TestCommand


with open("cyclecloud/version.py") as f:
    _version_line = f.readlines()[0]
__version__ = re.match(r'__version__ = "(\d+\.\d+\.\d+)-SNAPSHOT"', _version_line).group(1)


class PyTest(TestCommand):
    def finalize_options(self):
        TestCommand.finalize_options(self)
        xml_out = os.path.join('.', "build", "test-results", "pytest.xml")
        if not os.path.exists(os.path.dirname(xml_out)):
            os.makedirs(os.path.dirname(xml_out))
        self.test_args = ["tests", "--junitxml=%s" % xml_out]
        # needed for older setuptools to actually run this as a test
        self.test_suite = True

    def run_tests(self):
        # import here, cause outside the pytest eggs aren't loaded
        import pytest
        errno = pytest.main(self.test_args)
        sys.exit(errno)


setup(
    name="cyclecloud-api",
    version=__version__,
    packages=find_packages(exclude=["tests", "tests.*"]),
    install_requires=["requests==2.21.0", "six==1.12.0"] + ["certifi==2019.3.9", "chardet==3.0.4", "idna==2.8", "urllib3==1.24.1"],
    tests_require=["pytest==4.4.0"],
    cmdclass={"test": PyTest}
)
