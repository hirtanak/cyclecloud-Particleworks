from cyclecloud import session as _session
from cyclecloud import model as _model
from cyclecloud.api import clusters as _clusters
from requests.structures import CaseInsensitiveDict as _CaseInsensitiveDict


class Client(object):
    def __init__(self, config=None, **kwargs):
        self._session = _session.Session(config, **kwargs)
        self._clusters_manager = None

    @property
    def session(self):
        return self._session

    @property
    def clusters(self):
        if self._clusters_manager is None:
            self._clusters_manager = ClustersManager(self)
        return self._clusters_manager


class ClustersManager(object):
    def __init__(self, client):
        self._client = client

    def get(self, key):
        return Cluster(self._client, key)

    def __getitem__(self, key):
        return self.get(key)


class Cluster(object):
    def __init__(self, client, name):
        self._client = client
        self._name = name
        self._nodes_manager = None

    @property
    def name(self):
        return self._name

    @property
    def nodes(self):
        if self._nodes_manager is None:
            self._nodes_manager = NodesManager(self._client, self._name)
        return self._nodes_manager

    def get_status(self, nodes=False):
        _, s = _clusters.get_cluster_status(self._client.session, self._name, nodes=nodes)

        for nodearray in s.nodearrays:
            nodearray.nodearray = Record(nodearray.nodearray)

        if s.nodes:
            s.nodes = [Record(i) for i in s.nodes]

        return s

    def scale_by_cores(self, nodearray, total_core_count):
        _, s = _clusters.scale(self._client.session, self._name, nodearray, total_core_count=total_core_count)
        return s

    def scale_by_nodes(self, nodearray, total_node_count):
        _, s = _clusters.scale(self._client.session, self._name, nodearray, total_node_count=total_node_count)
        return s

class NodesManager(object):
    def __init__(self, client, cluster_name):
        self._client = client
        self._cluster_name = cluster_name
        self._pos = 0
        self._node_list = None

    def __iter__(self):
        self._pos = 0
        _, self._node_list = _clusters.get_nodes(self._client.session, self._cluster_name)
        return self

    def next(self):
        return self.__next__()

    def __next__(self):
        if self._pos < len(self._node_list.nodes):
            n = self._node_list.nodes[self._pos]
            self._pos += 1
            return Record(n)
        else:
            raise StopIteration


class Record(_CaseInsensitiveDict):
    def __init__(self, data=None, **kwargs):
        super(Record, self).__init__(data=data, **kwargs)

        for k in self:
            if isinstance(self[k], dict):
                self[k] = Record(self[k])

            elif isinstance(self[k], list):
                new_list = []
                for i in self[k]:
                    if isinstance(i, dict):
                        i = Record(i)
                    new_list.append(i)
                self[k] = new_list

    def to_dict(self):
        d = dict(self)
        for k in d:
            d[k] = Record._recurse_to_dict(d[k])

        return d

    @staticmethod
    def _recurse_to_dict(value):
        if isinstance(value, Record):
            return value.to_dict()

        elif isinstance(value, list):
            return [Record._recurse_to_dict(i) for i in value]

        elif isinstance(value, dict):
            return {k: Record._recurse_to_dict(value[k]) for k in value}

        return value

    @staticmethod
    def from_dict(dict_obj):
        return Record(dict_obj)
